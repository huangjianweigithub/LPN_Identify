package com.test.activity.charge;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageFormat;
import android.graphics.Rect;
import android.graphics.YuvImage;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.aiseminar.EasyPR.PlateRecognizer;
import com.aiseminar.util.BitmapUtil;
import com.aiseminar.util.FileUtil;


import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.List;

import butterknife.Bind;
import butterknife.OnClick;
import zxing.util.CameraManager;

public class CameraActivity extends Activity
        implements SurfaceHolder.Callback {


    private static final String TAG = CameraActivity.class.getSimpleName();
    @Bind(R.id.iv_camera_ok)
    ImageView ivCameraOk;
    @Bind(R.id.rl_camera_ok)
    RelativeLayout rlCameraOk;
    @Bind(R.id.iv_camera_retake)
    ImageView ivCameraRetake;
    @Bind(R.id.rl_camera_retake)
    RelativeLayout rlCameraRetake;
    @Bind(R.id.tv_lpn)
    TextView tvLpn;
    @Bind(R.id.ivPlateRect)
    ImageView mIvPlateRect;
    @Bind(R.id.tvPlateResult)
    TextView mTvPlateResult;
    @Bind(R.id.svCamera)
    SurfaceView mSvCamera;
    @Bind(R.id.iv_back)
    ImageView ivBack;
    @Bind(R.id.iv_light)
    ImageView ivLight;
    @Bind(R.id.rl_light)
    RelativeLayout rlLight;
    @Bind(R.id.tvComfirm)
    TextView tvComfirm;
    @Bind(R.id.ivCapturePhoto)
    ImageView ivCapturePhoto;
    @Bind(R.id.tvReset)
    TextView tvReset;
    private int cameraPosition = 0; // 0表示后置，1表示前置
    private SurfaceHolder mSvHolder;
    private Camera mCamera;
    private Camera.CameraInfo mCameraInfo;
    private MediaPlayer mShootMP;
    private PlateRecognizer mPlateRecognizer;
    private CarNo mCarNo = new CarNo();
    private boolean lightswitch = true, openCameraPs = false;
    private String lpnTip = "请将车牌置于方框内";

    @Override
    public void setView() {
        setContentView(R.layout.activity_camera);
    }

    @Override
    public void initDatas() {
        if (android.os.Build.VERSION.SDK_INT > 17) {
            mPlateRecognizer = new PlateRecognizer(this);
        } else {
            return;
        }
        if (!DataUtils.isCameraCanUse()) {
            showLongToast("请打开摄像头权限!");
            DataUtils.permissCamera(this);
            openCameraPs = true;
            return;
        }
        initData();
        //    CameraManager.init(getApplication());
    }


    @Override
    public void onStart() {
        super.onStart();
        if (this.checkCameraHardware(this) && (mCamera == null)) {
            // 打开camera
            mCamera = getCamera();
            // 设置camera方向
            mCameraInfo = getCameraInfo(Camera.CameraInfo.CAMERA_FACING_BACK);
            if (null != mCameraInfo) {
                adjustCameraOrientation();
            }
            if (mSvHolder != null && mCamera != null) {
                setStartPreview(mCamera, mSvHolder);
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        /**
         * 记得释放camera，方便其他应用调用
         */
        releaseCamera();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (mSvHolder != null) {
                CameraManager.get().openDriver(mSvHolder);
            }
        } catch (IOException ioe) {
            return;
        } catch (RuntimeException e) {
            return;
        }
    }

    /**
     * 初始化相关data
     */
    private void initData() {
        // 获得句柄
        mSvHolder = mSvCamera.getHolder(); // 获得句柄
        // 添加回调
        mSvHolder.addCallback(this);
    }

    private Camera getCamera() {
        Camera camera = null;
        try {
            camera = Camera.open();
        } catch (Exception e) {
            // Camera is not available (in use or does not exist)
            camera = null;
            Log.e(TAG, "Camera is not available (in use or does not exist)");
        }
        return camera;
    }

    private Camera.CameraInfo getCameraInfo(int facing) {
        int numberOfCameras = Camera.getNumberOfCameras();
        Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
        for (int i = 0; i < numberOfCameras; i++) {
            Camera.getCameraInfo(i, cameraInfo);
            if (cameraInfo.facing == facing) {
                return cameraInfo;
            }
        }
        return null;
    }

    private void adjustCameraOrientation() { // 调整摄像头方向
        if (null == mCameraInfo || null == mCamera) {
            return;
        }
        int orientation = this.getWindowManager().getDefaultDisplay().getOrientation();
        int degrees = 0;

        switch (orientation) {
            case Surface.ROTATION_0:
                degrees = 0;
                break;
            case Surface.ROTATION_90:
                degrees = 90;
                break;
            case Surface.ROTATION_180:
                degrees = 180;
                break;
            case Surface.ROTATION_270:
                degrees = 270;
                break;
        }

        int result;
        if (mCameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
            result = (mCameraInfo.orientation + degrees) % 360;
            result = (360 - result) % 360; // compensate the mirror
        } else {
            // back-facing
            result = (mCameraInfo.orientation - degrees + 360) % 360;
        }
        mCamera.setDisplayOrientation(result);
    }

    /**
     * 释放mCamera
     */
    private void releaseCamera() {
        if (mCamera != null) {
            mCamera.setPreviewCallback(null);
            mCamera.stopPreview();// 停掉原来摄像头的预览
            mCamera.release();
            mCamera = null;
        }
    }

    @OnClick({R.id.ivCapturePhoto, R.id.rl_camera_ok, R.id.rl_camera_retake, R.id.iv_back, R.id.iv_light})
    public void onClick(View view) {
        switch (view.getId()) {
            case 999: // R.id.id_switch_camera_btn:
                // 切换前后摄像头
                int cameraCount = 0;
                Camera.CameraInfo cameraInfo = new Camera.CameraInfo();
                cameraCount = Camera.getNumberOfCameras();// 得到摄像头的个数

                for (int i = 0; i < cameraCount; i++) {
                    Camera.getCameraInfo(i, cameraInfo);// 得到每一个摄像头的信息
                    if (cameraPosition == 1) {
                        // 现在是后置，变更为前置
                        if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                            /**
                             * 记得释放camera，方便其他应用调用
                             */
                            releaseCamera();
                            // 打开当前选中的摄像头
                            mCamera = Camera.open(i);
                            // 通过surfaceview显示取景画面
                            setStartPreview(mCamera, mSvHolder);
                            cameraPosition = 0;
                            break;
                        }
                    } else {
                        // 现在是前置， 变更为后置
                        if (cameraInfo.facing == Camera.CameraInfo.CAMERA_FACING_BACK) {
                            /**
                             * 记得释放camera，方便其他应用调用
                             */
                            releaseCamera();
                            mCamera = Camera.open(i);
                            setStartPreview(mCamera, mSvHolder);
                            cameraPosition = 1;
                            break;
                        }
                    }

                }
                break;
            case R.id.ivCapturePhoto:
                // 拍照,设置相关参数
                try {
                    mCamera.takePicture(shutterCallback, null, jpgPictureCallback);
                    ivCapturePhoto.setVisibility(View.INVISIBLE);
                    mTvPlateResult.setText("正在识别车牌号...");
                } catch (Exception e) {
                    Log.d(TAG, e.getMessage());
                }
                break;
            case R.id.rl_camera_ok: {
                //确认车牌号
                if (TextUtils.isEmpty(mCarNo.getLpn())) {
                    showBuider("请重新识别车牌!");
                    return;
                }
                if (recheckingLpn()) {
                    uploadCarNo();
                }
            }
            break;
            case R.id.rl_camera_retake: {
                //重拍
                rlCameraOk.setVisibility(View.GONE);
                rlCameraRetake.setVisibility(View.GONE);
                mTvPlateResult.setText(lpnTip);
                ivCapturePhoto.setVisibility(View.VISIBLE);
                tvLpn.setText("");
                mCarNo.setLpn(null);
                mCarNo.setUrl(null);
            }
            break;
            case R.id.iv_back: {
                finish();
            }
            break;
            case R.id.iv_light: {
                lightType();
            }
            break;
        }
    }



    private void lightType() {
        if (openCameraPs) {
            showLongToast("请打开摄像头权限!");
            return;
        }
        if (lightswitch) {
            try {
                if (mCamera == null) {
                    mCamera = Camera.open();
                }
                Camera.Parameters params = mCamera.getParameters();
                params.setFlashMode(Camera.Parameters.FLASH_MODE_TORCH);
                mCamera.setParameters(params);
                ivLight.setImageResource(R.mipmap.camera_lighton);
                lightswitch = false;
            } catch (Exception e) {
                showLongToast("请打开摄像头权限!");
            }
        } else {
            if (mCamera != null) {
                Camera.Parameters mParameters;
                mParameters = mCamera.getParameters();
                mParameters.setFlashMode(Camera.Parameters.FLASH_MODE_OFF);
                mCamera.setParameters(mParameters);
                ivLight.setImageResource(R.mipmap.camera_light);
                lightswitch = true;
            }
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        setStartPreview(mCamera, mSvHolder);
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // If your preview can change or rotate, take care of those events here.
        // Make sure to stop the preview before resizing or reformatting it.

        if (mSvHolder.getSurface() == null) {
            // preview surface does not exist
            return;
        }

        // stop preview before making changes
        try {
            mCamera.stopPreview();
        } catch (Exception e) {
            // ignore: tried to stop a non-existent preview
        }

        // set preview size and make any resize, rotate or
        // reformatting changes here

        // start preview with new settings
        setStartPreview(mCamera, mSvHolder);

        //实现自动对焦
        mCamera.autoFocus(new Camera.AutoFocusCallback() {
            @Override
            public void onAutoFocus(boolean success, Camera camera) {
                if (success) {
                    camera.cancelAutoFocus();//只有加上了这一句，才会自动对焦。
                }
            }
        });
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // 当surfaceview关闭时，关闭预览并释放资源
        /**
         * 记得释放camera，方便其他应用调用
         */
        releaseCamera();
        holder = null;
        mSvCamera = null;
    }

    /**
     * TakePicture回调
     */
    Camera.ShutterCallback shutterCallback = new Camera.ShutterCallback() {
        public void onShutter() {
            shootSound();
            mCamera.setOneShotPreviewCallback(previewCallback);
        }
    };

    Camera.PictureCallback rawPictureCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            camera.startPreview();
        }
    };

    Camera.PictureCallback jpgPictureCallback = new Camera.PictureCallback() {
        @Override
        public void onPictureTaken(byte[] data, Camera camera) {
            camera.startPreview();
            File pictureFile = FileUtil.getOutputMediaFile(FileUtil.FILE_TYPE_IMAGE);
            if (pictureFile == null) {
                Log.d(TAG, "Error creating media file, check storage permissions: ");
                return;
            }
            try {
                FileOutputStream fos = new FileOutputStream(pictureFile);
                // 照片转方向
                Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
                Bitmap normalBitmap = BitmapUtil.createRotateBitmap(bitmap);
//                fos.write(data);
                normalBitmap.compress(Bitmap.CompressFormat.JPEG, 20, fos);//压缩图片
                fos.close();
/*                // 更新图库
                // 把文件插入到系统图库
                try {
                    MediaStore.Images.Media.insertImage(CameraActivity.this.getContentResolver(),
                            pictureFile.getAbsolutePath(), pictureFile.getName(), "Photo taked by RoadParking.");
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }*/
                // 最后通知图库更新
                mCarNo.setUrl(pictureFile.getAbsolutePath());
/*                sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                        Uri.parse("file://" + pictureFile.getAbsolutePath())));
                showToast("图像已保存");*/
            } catch (FileNotFoundException e) {
                Log.d(TAG, "File not found: " + e.getMessage());
            } catch (IOException e) {
                Log.d(TAG, "Error accessing file: " + e.getMessage());
            }
        }
    };

    /**
     * Check if this device has a camera
     */
    private boolean checkCameraHardware(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) {
            // this device has a camera
            return true;
        } else {
            // no camera on this device
            return false;
        }
    }

    /**
     * 设置camera显示取景画面,并预览
     *
     * @param camera
     */
    private void setStartPreview(Camera camera, SurfaceHolder holder) {
        try {
            camera.setPreviewDisplay(holder);
            camera.startPreview();
        } catch (IOException e) {
            Log.d(TAG, "Error starting camera preview: " + e.getMessage());
        }
    }

    /**
     * 播放系统拍照声音
     */
    private void shootSound() {
        AudioManager meng = (AudioManager) this.getSystemService(Context.AUDIO_SERVICE);
        int volume = meng.getStreamVolume(AudioManager.STREAM_NOTIFICATION);

        if (volume != 0) {
            if (mShootMP == null)
                mShootMP = MediaPlayer.create(this,
                        Uri.parse("file:///system/media/audio/ui/camera_click.ogg"));
            if (mShootMP != null)
                mShootMP.start();
        }
    }

    /**
     * 获取Preview界面的截图，并存储
     */
    Camera.PreviewCallback previewCallback = new Camera.PreviewCallback() {
        @Override
        public void onPreviewFrame(byte[] data, Camera camera) {
            // 获取Preview图片转为bitmap并旋转
            Camera.Size size = mCamera.getParameters().getPreviewSize(); //获取预览大小
            final int w = size.width;  //宽度
            final int h = size.height;
            final YuvImage image = new YuvImage(data, ImageFormat.NV21, w, h, null);
            // 转Bitmap
            ByteArrayOutputStream os = new ByteArrayOutputStream(data.length);
            if (!image.compressToJpeg(new Rect(0, 0, w, h), 100, os)) {
                return;
            }
            byte[] tmp = os.toByteArray();
            Bitmap bitmap = BitmapFactory.decodeByteArray(tmp, 0, tmp.length);
            Bitmap rotatedBitmap = BitmapUtil.createRotateBitmap(bitmap);
            cropBitmapAndRecognize(rotatedBitmap);
        }
    };

    public void cropBitmapAndRecognize(Bitmap originalBitmap) {
        // 裁剪出关注区域
        DisplayMetrics metric = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(metric);
        int width = metric.widthPixels;  // 屏幕宽度（像素）
        int height = metric.heightPixels;  // 屏幕高度（像素）
        Bitmap sizeBitmap = Bitmap.createScaledBitmap(originalBitmap, width, height, true);

        int rectWidth = (int) (mIvPlateRect.getWidth() * 1.5);
        int rectHight = (int) (mIvPlateRect.getHeight() * 1.5);
        int[] location = new int[2];
        mIvPlateRect.getLocationOnScreen(location);
        location[0] -= mIvPlateRect.getWidth() * 0.5 / 2;
        location[1] -= mIvPlateRect.getHeight() * 0.5 / 2;
        Bitmap normalBitmap = Bitmap.createBitmap(sizeBitmap, location[0], location[1], rectWidth, rectHight);

        // 保存图片并进行车牌识别
        File pictureFile = FileUtil.getOutputMediaFile(FileUtil.FILE_TYPE_PLATE);
        if (pictureFile == null) {
            Log.d(TAG, "Error creating media file, check storage permissions: ");
            return;
        }
        try {
            mTvPlateResult.setText("正在识别...");
            FileOutputStream fos = new FileOutputStream(pictureFile);
            normalBitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
            fos.close();
            // 最后通知图库更新
            sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                    Uri.parse("file://" + pictureFile.getAbsolutePath())));
            // 进行车牌识别
            String plate = mPlateRecognizer.recognize(pictureFile.getAbsolutePath());
            MLog.i("车牌号：" + plate);
            if (!TextUtils.isEmpty(plate) && !plate.equalsIgnoreCase("0")) {
                if (plate.contains(":")) {
                    String[] result = plate.split(":");
                    if (result != null && result.length > 1) {
                        if (!TextUtils.isEmpty(result[1])) {
                            mCarNo.setLpn(URLEncoder.encode(result[1], "UTF-8"));
                        } else {
                            showToast("请重新扫描!");
                        }
                        tvLpn.setText(DataUtils.getLpn(result[1]));
                        tvLpn.setTextSize(32f);
                        mTvPlateResult.setText("请确认车牌是否识别正确");
                        rlCameraOk.setVisibility(View.VISIBLE);
                        rlCameraRetake.setVisibility(View.VISIBLE);
                        CacheUtils.getIn().save(mCarNo);
                    } else {
                        tvLpnTip();
                    }
                } else {
                    tvLpnTip();
                }
            } else {
                tvLpnTip();
            }

        } catch (FileNotFoundException e) {
            Log.d(TAG, "File not found: " + e.getMessage());
        } catch (IOException e) {
            Log.d(TAG, "Error accessing file: " + e.getMessage());
        }
    }

    private void tvLpnTip() {
        tvLpn.setText("请重新识别车牌!");
        tvLpn.setTextSize(16f);
        mTvPlateResult.setText(lpnTip);
        ivCapturePhoto.setVisibility(View.INVISIBLE);
        rlCameraOk.setVisibility(View.VISIBLE);
        rlCameraRetake.setVisibility(View.VISIBLE);
    }

    @Override
    public void onComplete(String result, int type) {

    }

    @Override
    public void onFailure(String msg, int type) {

    }

}
